﻿namespace Valid;

public interface IValidator
{
    string Apply(string input);
}
