﻿namespace ConfigurationManagement
{
    public class ConfigMngModule
    {
        public void ConfigMethod()
        {
            Console.WriteLine("Eu sunt Ioan :)");
        }
    }
}
