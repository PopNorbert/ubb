﻿namespace Logging
{
    public class LoggingModule
    {
        public void LoggingMethod()
        {
            Console.WriteLine("Eu sunt Ciprian :)");
        }
    }
}
